using UnityEngine;

public class Weapon : Pickup
{
	public float attackSpeed;
	public float damage;
	public TrailRenderer trailRenderer;
}
