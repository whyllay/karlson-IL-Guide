using UnityEngine;

public class Explosion : MonoBehaviour
{
	public bool player;
}
