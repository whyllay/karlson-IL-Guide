using UnityEngine;

public class Object : MonoBehaviour
{
}
