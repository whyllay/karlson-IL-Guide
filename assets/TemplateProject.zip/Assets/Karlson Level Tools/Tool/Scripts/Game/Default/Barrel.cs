using UnityEngine;

public class Barrel : MonoBehaviour
{
}
