using UnityEngine;

public class Bullet : MonoBehaviour
{
	public bool changeCol;
	public bool player;
	public bool explosive;
}
