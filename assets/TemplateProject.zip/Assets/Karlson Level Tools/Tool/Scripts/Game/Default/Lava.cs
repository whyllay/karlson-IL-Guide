﻿using UnityEngine;

public class Lava : MonoBehaviour { }
