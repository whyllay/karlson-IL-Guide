using UnityEngine;

public class Milk : MonoBehaviour
{
}
