using UnityEngine;

public class RangedWeapon : Weapon
{
	public GameObject projectile;
	public float pushBackForce;
	public float force;
	public float accuracy;
	public int bullets;
	public float boostRecoil;
}
