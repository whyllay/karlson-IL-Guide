using UnityEngine;

public class TextureScaling : MonoBehaviour
{
	public float size;
}
