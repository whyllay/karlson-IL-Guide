using UnityEngine;

public class Grappler : Pickup
{
	public LayerMask whatIsGround;
	public GameObject aim;
}
