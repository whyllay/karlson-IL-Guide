using UnityEngine;

public class RagdollController : MonoBehaviour
{
	public GameObject hips;
	public GameObject[] limbs;
	public Transform leftArm;
	public Transform rightArm;
	public Transform head;
	public Transform hand;
	public Transform hand2;
}
