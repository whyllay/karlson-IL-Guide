using UnityEngine;

public class Pickup : MonoBehaviour
{
	public float recoil;
}
