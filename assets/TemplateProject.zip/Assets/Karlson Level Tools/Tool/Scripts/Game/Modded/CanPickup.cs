﻿using UnityEngine;

namespace KarlsonLevelImporter.Core.Components
{
    [System.Serializable]
    public class CanPickup : MonoBehaviour, IObjectIdentifier
    {
        #region Identifier
        public Component component => this;
        public System.Type type => typeof(CanPickup);
        #endregion
    }
}