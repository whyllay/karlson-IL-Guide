﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace KarlsonLevelImporter.Core.Components
{
    [System.Serializable]
    public class PlayerStart : MonoBehaviour, IObjectIdentifier
    {
        #region Identifier
        public Component component => this;
        public System.Type type => typeof(PlayerStart);
        #endregion
    }
}