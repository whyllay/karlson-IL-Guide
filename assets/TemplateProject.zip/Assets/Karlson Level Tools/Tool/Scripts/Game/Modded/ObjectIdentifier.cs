﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// Solution for modded components not being able to cary over to the game
/// There's probably a better solution out there
/// - Jor02
/// </summary>
public interface IObjectIdentifier
{
    Component component { get; }
    System.Type type { get; }
}
