﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

[Serializable]
public class LevelScripts
{
    public List<ScriptedObject> objects = new List<ScriptedObject>();

    public void AddGameObject(GameObject obj)
    {
        objects.Add(new ScriptedObject(obj));
    }

    [Serializable]
    public class ScriptedObject
    {
        public string path;
        public List<ObjectComponent> components = new List<ObjectComponent>();

        public ScriptedObject(GameObject target)
        {
            path = GetGameObjectPath(target);
            var identifiers = target.GetComponentsInChildren<MonoBehaviour>().OfType<IObjectIdentifier>();

            foreach (IObjectIdentifier identifier in identifiers)
            {
                components.Add(new ObjectComponent(identifier));
            }
        }

        [Serializable]
        public class ObjectComponent
        {
            public string typeName;
            public List<Member> members = new List<Member>();

            public ObjectComponent(IObjectIdentifier identifier)
            {
                Component comp = identifier.component;
                Type type = identifier.type;
                typeName = type.FullName;

                foreach (FieldInfo memberInfo in type.GetFields())
                {
                    if (memberInfo.DeclaringType != type) continue;
                    if (!memberInfo.IsPublic || memberInfo.IsInitOnly) continue;

                    members.Add(new Member(memberInfo.Name, memberInfo.GetValue(comp)));
                }
            }

            [Serializable]
            public struct Member
            {
                public string name;
                public string value;
                public Member(string Name, object Value)
                {
                    name = Name;
                    value = Value.ToString();
                }
            }
        }

        /// <summary>
        /// Returns the path to a GameObject.
        /// Source: http://answers.unity.com/answers/8502/view.html
        /// </summary>
        private static string GetGameObjectPath(GameObject obj)
        {
            string path = "/" + obj.name;
            while (obj.transform.parent != null)
            {
                obj = obj.transform.parent.gameObject;
                path = "/" + obj.name + path;
            }
            return path;
        }
    }
}
